package Data_structure_stack;

public interface Stack {
    public void push(Object o);
    public Object pop();
    public boolean isEmpty();

}
