package Data_structure_stack;

public interface Array {
    public Object get(int i);
    public void set(int i, Object data);
    public int size();
}
